<?php

namespace TitanCore\Contracts;

interface PlatformRegistryInterface
{
    public function register(string $type,string $name,mixed $definition): void;
    public function resolve(string $type,string $name): mixed;
    public function all(string $type): array;
}
