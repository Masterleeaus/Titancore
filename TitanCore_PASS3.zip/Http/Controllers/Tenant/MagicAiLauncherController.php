<?php
// TODO V1.9: UI controllers should be moved from TitanCore into workspace module.
<?php

namespace Modules\TitanCore\Http\Controllers\Tenant;

use Illuminate\Routing\Controller;

class MagicAiLauncherController extends Controller
{
    public function index()
    {
        return view('titancore::tenant.magicai.launcher');
    }
}
